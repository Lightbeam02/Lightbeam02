export const API_ENDPOINT = "https://discord.com/api/v9";
export const MAX_EMBED_FIELD_CHARS = 1024;
export const MAX_EMBED_FOOTER_CHARS = 2048;
